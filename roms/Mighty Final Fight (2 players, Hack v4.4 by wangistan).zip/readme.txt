Mighty Final Fight for 2 players
    2P is able to control the enemies.

2P can press SELECT to change the person that would be controlled.
    2P can use all the enemies’ skills, including the laugh of the final boss.

In particular, the kiss skill of the boss3 is made to be a passive skill.
    There will be an arrow at the bottom of the screen for displaying the position of 2P.

If 2P stand outside the screen, the arrow will stay at the corresponding edge of the screen.
    1P can change the leading role (Cody-Guy-Haggar-Cody…) by pressing SELECT+UP (SELECT must be the previous key).

This is valid when the leading role is under control and standing on the ground.

This will clear your current EXP.
    1P can press SELECT+RIGHT (SELECT must be the previous key) to jump to the next arena.

This is valid when the leading role is under control and standing on the ground.
    1P and 2P can exchange the joypad. That means 1P controls the enemies and 2P controls the leading role.

1P or 2P press SELECT+LEFT (SELECT must be the previous key) to do this.
